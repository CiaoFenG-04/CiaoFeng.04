// User
var userListUrl = 'http://127.0.0.1:5000/getUsers'
var userInsertInsertUrl = 'http://127.0.0.1:5000/insertUser'

// Product
var productListUrl = 'http://127.0.0.1:5000/getProducts'
var productUpdateUrl = 'http://127.0.0.1:5000/updateQuantity'

// Order
var ordersListUrl = 'http://127.0.0.1:5000/getOrders'
var insertOrder = 'http://127.0.0.1:5000/insertOrder'

// Page
var groceryPage = 'http://127.0.0.1:5000/grocery'

// Login
var login = 'http://127.0.0.1:5000/login'

// Logout
var logout = 'http://127.0.0.1:5000/logout'